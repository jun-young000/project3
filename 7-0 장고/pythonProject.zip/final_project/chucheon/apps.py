from django.apps import AppConfig


class RestChucheonConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chucheon'
