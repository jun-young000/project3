$(function() {
    var dest = $("#inputDestination").val()


});